package com.amozonclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmozoncloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmozoncloneApplication.class, args);
	}

}
